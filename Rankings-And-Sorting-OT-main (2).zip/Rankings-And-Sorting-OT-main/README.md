Simple numpy Implementation of paper Differentiable Ranks and Sorting using Optimal Transport by Marco Cuturi Olivier Teboul Jean-Philippe Vert.

